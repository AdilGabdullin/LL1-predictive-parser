#!/bin/bash
javac Main.java
java Main tests/invalid01.txt
java Main tests/invalid02.txt
java Main tests/invalid03.txt
java Main tests/invalid04.txt
java Main tests/invalid05.txt
java Main tests/invalid06.txt
java Main tests/invalid07.txt
java Main tests/invalid08.txt
java Main tests/invalid09.txt
java Main tests/invalid10.txt
java Main tests/invalid11.txt
java Main tests/invalid12.txt
java Main tests/invalid13.txt
java Main tests/invalid14.txt
java Main tests/invalid15.txt

java Main tests/valid01.txt
java Main tests/valid02.txt
java Main tests/valid03.txt
java Main tests/valid04.txt