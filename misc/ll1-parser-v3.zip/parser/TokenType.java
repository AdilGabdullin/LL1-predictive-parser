package parser;

public enum TokenType {
  KEYWORD,
  OPERATOR,
  NAME,
  INTEGER_VALUE,
  DELIMETER,
  UNKNOWN,
}
