Usage:
    java Main tests/valid01.txt

Commands:
    compile: javac Main.java
    run: java Main <FILENAME>
    run in verbose mode: java Main <FILENAME> verbose
    tests: bash run-tests.sh

Classes:
    Token: primitive data transfer class
    TokenType: enum KEYWORD, OPERATOR, NAME, INTEGER_VALUE, DELIMETER, UNKNOWN
    Tokenizer: takes code, returns queue of tokens
    ParsingTable: derrivation table
    Parser: parse code, prints "Successfully parsed" or detailed error.
        In verbose mode also outputs stack, token and symbol table on each iteration
