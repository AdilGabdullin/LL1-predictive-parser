#!/bin/bash
javac Main.java 
java Main tests/valid01.txt verbose
