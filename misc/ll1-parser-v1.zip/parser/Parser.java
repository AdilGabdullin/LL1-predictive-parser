package parser;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import parser.ParsingTable;
import parser.Token;
import parser.Tokenizer;

public class Parser {

  public boolean verbose = false;
  private Queue<Token> tokens;
  private ParsingTable table;
  private Stack<String> stack;

  public Parser() {
    table = new ParsingTable();
  }

  public void parse(String code) {
    if (verbose) System.out.println(code);
    tokens = Tokenizer.getTokens(code);
    initStack(code);
    while (!stack.peek().equals("$") && tokens.size() > 0) {
      printState();
      if (stack.peek().equals("integer-value")) {
        parseIntegerValue();
      } else if (stack.peek().equals("name")) {
        parseName();
      } else if (currentTableRow() == null) {
        parsePrimitive();
      } else if (currentDerivation() == null) {
        parseLambda();
      } else {
        parseDerivation();
      }
    }
    printState();
    parseEnd();
  }

  private void initStack(String code) {
    stack = new Stack<String>();
    stack.push("$");
    stack.push("project-declaration");
  }

  private void printState() {
    if (!verbose) return;
    System.out.print("stack: ");
    System.out.print(stack);
    String value = tokens.size() > 0 ? tokens.peek().value : null;
    System.out.println(" token: \"" + value + "\"");
  }

  private Map<String, String[]> currentTableRow() {
    return table.get(stack.peek());
  }

  private String[] currentDerivation() {
    if (currentTableRow() == null) return null;
    if (tokens.peek().type == TokenType.NAME) {
      return currentTableRow().get("name");
    }
    if (tokens.peek().type == TokenType.INTEGER_VALUE) {
      return currentTableRow().get("integer-value");
    }
    return currentTableRow().get(tokens.peek().value);
  }

  private void parseEnd() {
    if (tokens.size() > 0 || stack.size() > 1) error();
    System.out.println("Successfully parsed");
  }

  private void parseIntegerValue() {
    if (tokens.peek().type != TokenType.INTEGER_VALUE) error();
    tokens.remove();
    stack.pop();
  }

  private void parseName() {
    if (tokens.peek().type != TokenType.NAME) error();
    tokens.remove();
    stack.pop();
  }

  private void parsePrimitive() {
    if (!stack.peek().equals(tokens.peek().value)) error();
    tokens.remove();
    stack.pop();
  }

  private void parseLambda() {
    if (currentTableRow().get("lambda") == null) error();
    stack.pop();
  }

  private void parseDerivation() {
    String[] derivation = currentDerivation();
    stack.pop();
    for (int i = derivation.length - 1; i >= 0; i--) {
      stack.push(derivation[i]);
    }
  }

  private void error() {
    String message = "ERROR!\nexpected \"" + stack.peek() + "\"";
    if (tokens.size() == 0) {
      System.out.println(message + " found end of file");
      System.exit(1);
    }
    Token token = tokens.peek();
    System.out.println(
      message + " found \"" + token.value + "\" at line " + token.line
    );
    System.exit(1);
  }
}
